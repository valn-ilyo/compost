<!-- Component -- confirmation card shown when all habits are logged for the day -->
<template>
  <VCard
    v-motion
    :initial="{ opacity: 0, y: 28, scale: 0.96 }"
    :enter="{
      opacity: 1,
      y: 0,
      scale: 1,
      transition: { type: 'spring', stiffness: 300, damping: 22, delay: 80 },
    }"
    color="primary-container"
    variant="flat"
    rounded
    prepend-icon="mdi-check-decagram"
  >
    <template #title>
      <div class="text-title-large">All logged for today</div>
    </template>
  </VCard>
</template>
