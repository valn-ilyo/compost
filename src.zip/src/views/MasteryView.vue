<!-- View -- mastery screen with habit list, log-all action, and habit library -->
<script setup lang="ts">
import { onMounted, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useMasteryStore } from '@/stores/mastery.store'
import { FREEZE_CAP } from '@/types/app.types'
import { useMasteryRecommendations } from '@/composables/useMasteryRecommendations'
import { useMasteryCheckIn } from '@/composables/useMasteryCheckIn'
import { useMasteryActions } from '@/composables/useMasteryActions'
import HabitCard from '@/components/habit/HabitCard.vue'
import HabitLibrary from '@/components/habit/HabitLibrary.vue'
import AllLoggedCard from '@/components/habit/AllLoggedCard.vue'
import MasteryCheckinSheet from '@/components/mastery/MasteryCheckInSheet.vue'
import MasterySwapSheet from '@/components/mastery/MasterySwapSheet.vue'
import MasteryFreezeInfo from '@/components/mastery/MasteryFreezeInfo.vue'

const route = useRoute()
const router = useRouter()
const store = useMasteryStore()
const { recommendedIds } = useMasteryRecommendations()
const {
  checkinOpen,
  checkinHabitId,
  showAllLogged,
  logLabel,
  displayMasteredToday,
  displayLostStreak,
  handleLog,
  handleLogAll,
  handleCheckinDone,
} = useMasteryCheckIn()
const {
  swapOpen,
  pendingTemplate,
  pendingAction,
  handleAdd,
  handleResume,
  handlePause,
  handleRemove,
  handleSwap,
  handleRetire,
} = useMasteryActions()

onMounted(async () => {
  if (route.query.action === 'log' && store.activeHabits.length > 0) {
    await router.replace({ name: 'mastery' })
    handleLogAll()
  }
})

watch(
  () => route.query.action,
  async (action) => {
    if (action === 'log' && store.activeHabits.length > 0) {
      await router.replace({ name: 'mastery' })
      handleLogAll()
    }
  },
)
</script>

<template>
  <VContainer class="pt-0 overflow-hidden">
    <VRow justify="center">
      <VCol cols="12" md="8">
        <div
          v-motion
          :initial="{ opacity: 0, y: -12 }"
          :enter="{ opacity: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 22 } }"
        >
          <VToolbar flat color="transparent">
            <VToolbarTitle class="d-flex align-center">
              Mastery
              <VChip variant="text" color="secondary" class="font-weight-bold count-chip">
                <Transition name="count-swap" mode="out-in">
                  <span :key="store.usedSlots">{{ store.usedSlots }}</span>
                </Transition>
                <span>&nbsp;/ 3</span>
              </VChip>
            </VToolbarTitle>
            <template #append>
              <div class="d-flex align-center">
                <MasteryFreezeInfo
                  class="mr-3"
                  :freeze-count="store.freezeCount"
                  :freeze-cap="FREEZE_CAP"
                  :days-to-next-freeze="store.daysToNextFreeze"
                  :days-to-next-mastery="store.daysToNextMastery"
                  :any-freeze-used="store.activeHabits.some((h) => h.freezeUsed)"
                  :mastered-today="displayMasteredToday"
                />
              </div>
            </template>
          </VToolbar>
        </div>

        <Transition name="mastery-section" mode="out-in">
          <div
            v-if="store.activeHabits.length === 0 && store.masteredHabits.length === 0"
            key="empty"
          >
            <VAlert
              type="success"
              variant="text"
              icon="mdi-sprout"
              class="mb-4"
              title="No habits yet"
              text="Choose up to 3 from the library below."
            />
          </div>

          <div v-else key="habits">
            <VCard variant="outlined" rounded="lg" class="mb-4 overflow-hidden">
              <TransitionGroup name="habit" tag="div" class="habit-list">
                <div v-for="habit in store.masteredHabits" :key="habit.id" class="habit-row">
                  <HabitCard
                    :habit="habit"
                    :is-logged-today="false"
                    @retire="handleRetire"
                    @log="() => {}"
                    @pause="() => {}"
                    @remove="() => {}"
                  />
                </div>
                <div v-for="habit in store.activeHabits" :key="habit.id" class="habit-row">
                  <HabitCard
                    :habit="habit"
                    :is-logged-today="store.isLoggedToday(habit.templateId)"
                    :lost-streak="displayLostStreak(habit.templateId)"
                    @log="handleLog"
                    @pause="handlePause"
                    @remove="handleRemove"
                    @retire="() => {}"
                  />
                </div>
              </TransitionGroup>
            </VCard>

            <VExpandTransition>
              <div v-if="!showAllLogged && store.activeHabits.length > 0">
                <VBtn
                  block
                  size="large"
                  color="primary"
                  rounded="lg"
                  variant="flat"
                  class="mb-6"
                  @click="handleLogAll"
                >
                  <Transition name="label-swap" mode="out-in">
                    <span :key="logLabel" class="label-text">{{ logLabel }}</span>
                  </Transition>
                </VBtn>
              </div>
            </VExpandTransition>

            <VExpandTransition>
              <div v-if="showAllLogged">
                <AllLoggedCard class="mb-6" />
              </div>
            </VExpandTransition>
          </div>
        </Transition>

        <VDivider class="mb-6" />

        <div
          v-motion
          :initial="{ opacity: 0, y: 32 }"
          :enter="{
            opacity: 1,
            y: 0,
            transition: {
              type: 'spring',
              stiffness: 300,
              damping: 22,
              delay: store.activeHabits.length * 80 + 160,
            },
          }"
        >
          <HabitLibrary :recommended-ids="recommendedIds" @add="handleAdd" @resume="handleResume" />
        </div>
      </VCol>
    </VRow>
  </VContainer>

  <MasteryCheckinSheet v-model="checkinOpen" :habit-id="checkinHabitId" @done="handleCheckinDone" />
  <MasterySwapSheet
    v-model="swapOpen"
    :pending-template="pendingTemplate"
    :pending-action="pendingAction"
    @swap="handleSwap"
  />
</template>

<style scoped>
/* ── empty ↔ habits cross-fade ── */
.mastery-section-enter-active {
  transition: opacity 180ms ease;
}
.mastery-section-leave-active {
  transition:
    opacity 200ms ease,
    transform 200ms ease;
}
.mastery-section-enter-from {
  opacity: 0;
}
.mastery-section-leave-to {
  opacity: 0;
  transform: translateY(-6px);
}

/* ── count chip number swap ── */
.count-swap-enter-active,
.count-swap-leave-active {
  transition: opacity 120ms ease;
}
.count-swap-enter-from,
.count-swap-leave-to {
  opacity: 0;
}

/* ── log button label swap ── */
.label-swap-enter-active,
.label-swap-leave-active {
  transition: opacity 110ms ease;
}
.label-swap-leave-active {
  position: absolute;
}
.label-swap-enter-from,
.label-swap-leave-to {
  opacity: 0;
}
.label-text {
  display: inline-block;
}

/* ── habit list container ── */
.habit-list {
  position: relative;
}

.habit-row + .habit-row {
  border-top: thin solid rgba(var(--v-border-color), var(--v-border-opacity));
}

/* ── TransitionGroup animation classes ── */
.habit-enter-active {
  transition:
    opacity 300ms cubic-bezier(0.4, 0, 0.2, 1),
    transform 300ms cubic-bezier(0.4, 0, 0.2, 1);
}
.habit-enter-from {
  opacity: 0;
  transform: translateY(14px);
}

.habit-leave-active {
  transition:
    opacity 240ms cubic-bezier(0.4, 0, 0.2, 1),
    transform 240ms cubic-bezier(0.4, 0, 0.2, 1);
  position: absolute;
  width: 100%;
}
.habit-leave-to {
  opacity: 0;
  transform: translateX(32px);
}

.habit-move {
  transition: transform 300ms cubic-bezier(0.4, 0, 0.2, 1);
}

:deep(.v-list-item-subtitle) {
  opacity: 1 !important;
}
</style>
