<script setup lang="ts">
import { computed, ref } from "vue"
import type { ComponentPublicInstance } from "vue"
import { useElementSize } from "@vueuse/core"
import { useRouter } from "vue-router"
import { useAssessmentStore } from "@/stores/assessment"
import { useMasteryStore } from "@/stores/mastery"
import { usePwaInstall } from "@/composables/usePwaInstall"
import { useNotificationPrompt } from "@/composables/useNotificationPrompt"
import { SECTIONS } from "@/data"
import AppBarHome from "@/components/app/AppBarHome.vue"
import ClimateHeadlines from "@/components/climate/ClimateHeadlines.vue"
import PwaInstallBanner from "@/components/pwa/PwaInstallBanner.vue"
import NotificationPromptBanner from "@/components/notification/NotificationPromptBanner.vue"
import AllLoggedCard from "@/components/habit/AllLoggedCard.vue"

const store = useAssessmentStore()
const masteryStore = useMasteryStore()
const router = useRouter()

// TODO [HomeView > assessment CTA card]
// nextSection: first section not yet in sectionResults
const completedIds = computed(() => new Set(store.sectionResults.map((r) => r.meta.id)))
const hasStarted = computed(() => store.sectionResults.length > 0)
const nextSection = computed(() => SECTIONS.find((s) => !completedIds.value.has(s.id)))

// TODO [HomeView > Log your habits CTA card]
// Shown when active habits exist AND not all logged today
const showLogButton = computed(
  () => masteryStore.activeHabits.length > 0 && !masteryStore.allLoggedToday,
)

// TODO [HomeView > AllLoggedCard]
// Shown when active habits exist AND all logged today
const showAllDoneCard = computed(
  () => masteryStore.activeHabits.length > 0 && masteryStore.allLoggedToday,
)

// TODO [HomeView > Log your habits CTA card tap]
// Navigate to /mastery?action=log
function goToLog(): void {
  router.push({ name: "mastery", query: { action: "log" } })
}

const { isIos, installPrompt, showInstallBanner, triggerInstall } = usePwaInstall()
const { showNotificationBanner, requestPermission } = useNotificationPrompt()

const cardRef = ref<ComponentPublicInstance | null>(null)
const { width: cardWidth } = useElementSize(
  computed(() => (cardRef.value as ComponentPublicInstance)?.$el as HTMLElement ?? null),
)
</script>

<template>
  <AppBarHome />
  <v-container>
    <v-row justify="center">
      <v-col cols="12" md="8" class="d-flex flex-column ga-3">
        <ClimateHeadlines />

        <template v-if="nextSection">
          <v-tooltip
            :text="nextSection.description"
            location="bottom"
            :content-props="{ style: `max-width: ${cardWidth}px; white-space: normal;` }"
          >
            <template #activator="{ props: tooltipProps }">
              <v-card
                v-bind="tooltipProps"
                ref="cardRef"
                v-motion
                :initial="{ opacity: 0, y: 28, scale: 0.96 }"
                :enter="{
                  opacity: 1,
                  y: 0,
                  scale: 1,
                  transition: { type: 'spring', stiffness: 300, damping: 22 },
                }"
                :to="`/assessment/${nextSection.id}`"
                color="tertiary-container"
                variant="flat"
                rounded
                :prepend-icon="nextSection.icon"
                append-icon="mdi-chevron-double-right"
              >
                <template #title>
                  <div>
                    <div class="text-label-small text-uppercase">
                      {{ hasStarted ? "Continue your assessment" : "Start your assessment" }}
                    </div>
                    <div class="text-title-large mb-1">
                      {{ nextSection.label }}
                    </div>
                  </div>
                </template>
              </v-card>
            </template>
          </v-tooltip>
        </template>

        <v-card
          v-if="showLogButton"
          v-motion
          :initial="{ opacity: 0, y: 28, scale: 0.96 }"
          :enter="{
            opacity: 1,
            y: 0,
            scale: 1,
            transition: { type: 'spring', stiffness: 300, damping: 22, delay: 80 },
          }"
          color="primary-container"
          variant="flat"
          rounded
          prepend-icon="mdi-leaf"
          append-icon="mdi-chevron-double-right"
          @click="goToLog"
        >
          <template #title>
            <div class="text-title-large">Log your habits</div>
          </template>
        </v-card>

        <AllLoggedCard v-if="showAllDoneCard" />

        <PwaInstallBanner
          :show="showInstallBanner"
          :has-install-prompt="!!installPrompt"
          :is-ios="isIos"
          @install="triggerInstall"
        />

        <NotificationPromptBanner
          :show="showNotificationBanner && masteryStore.activeHabits.length > 0"
          @enable="requestPermission"
        />
      </v-col>
    </v-row>
  </v-container>
</template>
