<script setup lang="ts">
import { ref } from "vue";
import { supabase } from "@/lib/supabaseClient.ts";
import { useNotifier } from "@/composables/useNotifier";
const { notify } = useNotifier();
const loading = ref(false);
const errorMsg = ref("");
const loginWithGoogle = async () => {
  loading.value = true;
  errorMsg.value = "";
  try {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: window.location.origin + "/compost/",
      },
    });
    if (error) {
      errorMsg.value = `Login failed: ${error.message}`;
      loading.value = false;
    }
  } catch (err) {
    notify({
      message: err instanceof Error ? err.message : "An unexpected error occurred",
      color: "error",
    });
    loading.value = false;
  }
};
</script>

<template>
  <v-sheet
    color="background"
    class="d-flex flex-column align-center justify-center w-100 px-2"
    style="min-height: 100dvh"
  >
    <v-card
      v-motion
      :initial="{ opacity: 0, y: 24 }"
      :enter="{ opacity: 1, y: 0, transition: { type: 'spring', stiffness: 260, damping: 22 } }"
      class="text-onSecondaryContainer w-100 w-sm-75 w-md-50 w-lg-33 pa-2 text-center"
      color="background"
      elevation="0"
      style="opacity: 0"
    >
      <div
        v-motion
        :initial="{ opacity: 0, scale: 0.7, rotate: -15 }"
        :enter="{ opacity: 1, scale: 1, rotate: 0, transition: { type: 'spring', stiffness: 260, damping: 22 } }"
        style="opacity: 0; display: inline-block"
      >
        <v-icon icon="custom:sac" size="160" />
      </div>

      <v-card-title
        v-motion
        :initial="{ opacity: 0, y: 12 }"
        :enter="{ opacity: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 22, delay: 80 } }"
        class="text-primary text-headline-medium font-weight-bold"
        style="opacity: 0"
      >Compost</v-card-title>

      <v-card-text
        v-motion
        :initial="{ opacity: 0, y: 10 }"
        :enter="{ opacity: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 22, delay: 140 } }"
        style="opacity: 0"
      >
        Find out what your daily habits actually cost the planet. Answer questions across transport,
        food, energy, and more. See where you stand and where small changes would matter most.
      </v-card-text>

      <v-card-actions class="d-flex flex-column align-center justify-center">
        <v-btn
          :loading="loading"
          :disabled="loading"
          text="Continue with Google"
          class="text-none rounded-xl border border-thin border-opacity-100"
          hover
          color="background"
          variant="flat"
          elevation="1"
          @click="loginWithGoogle"
        >
          <template #prepend>
            <v-icon>
              <svg
                version="1.1"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 48 48"
                xmlns:xlink="http://www.w3.org/1999/xlink"
                style="display: block"
              >
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                <path fill="none" d="M0 0h48v48H0z"></path>
              </svg>
            </v-icon>
          </template>
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-sheet>
</template>
