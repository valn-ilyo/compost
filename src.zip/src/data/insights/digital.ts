import type { QuestionInsight } from "@/types/app";

export const DIGITAL_INSIGHTS: QuestionInsight[] = [
  // streaming_habits
  {
    sectionId: "digital",
    questionId: "streaming_habits",
    score: 5,
    icon: "mdi-video-off-outline",
    text: "Under one hour per day at SD or audio-only is the lowest-impact streaming pattern. Both duration and quality are at the right level.",
  },
  {
    sectionId: "digital",
    questionId: "streaming_habits",
    score: 4,
    icon: "mdi-video-off-outline",
    text: "One to two hours at SD quality manages quality correctly. The remaining gap is duration: consider replacing 15 minutes of video with audio-only to go further.",
  },
  {
    sectionId: "digital",
    questionId: "streaming_habits",
    score: 3,
    icon: "mdi-video-off-outline",
    text: "One to two hours at HD means quality is the primary issue. SD uses roughly 20 times less data per hour than HD with minimal visible difference for most content. Go into your app settings and change it now.",
  },
  {
    sectionId: "digital",
    questionId: "streaming_habits",
    score: 2,
    icon: "mdi-video-off-outline",
    text: "Three to four hours at HD is both high duration and high quality. Set a daily time limit and switch to SD in your app settings today. Either change alone reduces the footprint significantly.",
  },
  {
    sectionId: "digital",
    questionId: "streaming_habits",
    score: 1,
    icon: "mdi-video-off-outline",
    text: "4K streaming at over four hours per day transfers roughly 100 times the data of SD per hour. Switch your quality setting to SD now and set a daily time reminder. Both changes, today.",
  },

  // cloud_hygiene
  {
    sectionId: "digital",
    questionId: "cloud_hygiene",
    score: 5,
    icon: "mdi-delete-sweep-outline",
    text: "Regularly reviewing and deleting unused files keeps cloud storage lean and reduces the continuous server energy required to maintain it.",
  },
  {
    sectionId: "digital",
    questionId: "cloud_hygiene",
    score: 4,
    icon: "mdi-delete-sweep-outline",
    text: "Deleting occasionally when storage fills is reactive rather than proactive. Set a monthly calendar reminder for a cleanup so it happens on a schedule, not only when the storage notification appears.",
  },
  {
    sectionId: "digital",
    questionId: "cloud_hygiene",
    score: 3,
    icon: "mdi-delete-sweep-outline",
    text: "Rarely deleting means storage accumulates continuously. Set a monthly 15-minute calendar reminder now. That one recurring entry converts occasional awareness into action.",
  },
  {
    sectionId: "digital",
    questionId: "cloud_hygiene",
    score: 2,
    icon: "mdi-delete-sweep-outline",
    text: "Never deleting means storage grows indefinitely and cloud energy draw is at its maximum. Start with one focused session: delete your oldest or largest unused files today.",
  },
  {
    sectionId: "digital",
    questionId: "cloud_hygiene",
    score: 1,
    icon: "mdi-delete-sweep-outline",
    text: "Automatic backup across multiple accounts without review is one of the largest sources of unnecessary cloud load. Open one cloud folder this week and spend 10 minutes deleting what you no longer need.",
  },

  // email_hygiene
  {
    sectionId: "digital",
    questionId: "email_hygiene",
    score: 5,
    icon: "mdi-email-outline",
    text: "Regularly archiving, deleting, and unsubscribing means your inbox is actively managed rather than passively accumulating. Unsubscribing prevents emails from arriving rather than just deleting them after.",
  },
  {
    sectionId: "digital",
    questionId: "email_hygiene",
    score: 4,
    icon: "mdi-email-outline",
    text: "Periodically deleting spam and unnecessary emails is good active management. The remaining gap is mailing lists: unsubscribe from ones you no longer read to prevent them arriving in the first place.",
  },
  {
    sectionId: "digital",
    questionId: "email_hygiene",
    score: 3,
    icon: "mdi-email-outline",
    text: "Letting emails accumulate with occasional deletion means the inbox is growing faster than it's being cleared. Set a weekly 10-minute slot on the same day each week and unsubscribe from five mailing lists in that time.",
  },
  {
    sectionId: "digital",
    questionId: "email_hygiene",
    score: 2,
    icon: "mdi-email-outline",
    text: "Rarely deleting means your inbox holds years of emails that serve no function. Start in your promotions or newsletters folder: delete everything older than one month.",
  },
  {
    sectionId: "digital",
    questionId: "email_hygiene",
    score: 1,
    icon: "mdi-email-outline",
    text: "Never managing your inbox means storage and server load grow unchecked. Delete everything in your junk or promotional folder older than a month. That one action is the beginning.",
  },

  // intentional_use
  {
    sectionId: "digital",
    questionId: "intentional_use",
    score: 5,
    icon: "mdi-cellphone-off",
    text: "Using devices for specific purposes and closing apps when done means data transfer occurs only when you intend it. Passive scrolling generates continuous load that intentional use avoids.",
  },
  {
    sectionId: "digital",
    questionId: "intentional_use",
    score: 4,
    icon: "mdi-cellphone-off",
    text: "Mostly intentional use with occasional passive scrolling is close to the target. The gap is noticing when passive scrolling begins: a screen time daily summary makes that visible.",
  },
  {
    sectionId: "digital",
    questionId: "intentional_use",
    score: 3,
    icon: "mdi-cellphone-off",
    text: "Regular passive scrolling alongside intentional use means a significant portion of device time generates unnecessary data transfer. Set a daily screen time limit or a specific no-scroll window each day.",
  },
  {
    sectionId: "digital",
    questionId: "intentional_use",
    score: 2,
    icon: "mdi-cellphone-off",
    text: "Often scrolling without purpose means most of your device time is passive. Set a 20-minute daily limit for social media and browsing. Passive video scrolling in particular generates significant and unnecessary data load.",
  },
  {
    sectionId: "digital",
    questionId: "intentional_use",
    score: 1,
    icon: "mdi-cellphone-off",
    text: "Mostly passive and largely uncontrolled device use means the majority of your data and screen time is unintended. State a purpose before picking up your phone today. That one moment of intention is the start.",
  },

  // device_repair
  {
    sectionId: "digital",
    questionId: "device_repair",
    score: 5,
    icon: "mdi-tools",
    text: "Always choosing repair first extends device life and avoids repeating the manufacturing footprint (roughly 70 to 80 kg CO₂ for a smartphone) for as long as the device functions.",
  },
  {
    sectionId: "digital",
    questionId: "device_repair",
    score: 4,
    icon: "mdi-tools",
    text: "Usually repairing minor issues and replacing only if unrepairable is a responsible pattern. The gap is the definition of unrepairable: get a second opinion from a local technician before concluding a device can't be fixed.",
  },
  {
    sectionId: "digital",
    questionId: "device_repair",
    score: 3,
    icon: "mdi-tools",
    text: "Trying repair once and replacing if it's not a quick fix means many repairable devices are discarded. Check repair cafes or local technicians: many repairs that appear complex are straightforward and cheap.",
  },
  {
    sectionId: "digital",
    questionId: "device_repair",
    score: 2,
    icon: "mdi-tools",
    text: "Replacing because repair seems too complicated or expensive is a decision often made without getting a quote. Consult a local repair technician before your next replacement: battery repairs in particular are usually fast and inexpensive.",
  },
  {
    sectionId: "digital",
    questionId: "device_repair",
    score: 1,
    icon: "mdi-tools",
    text: "Replacing immediately at every upgrade opportunity means devices are discarded with most of their life unused. Skip one upgrade cycle and get a repair quote on your current device first.",
  },
];
