<script setup lang="ts">
import { useDisplay } from "vuetify";
import type { UserHabit } from "@/types/app.types";

// ─── Props / emits ────────────────────────────────────────────────────────────

defineProps<{
  modelValue: boolean;
  habit: UserHabit | null;
}>();

const emit = defineEmits<{
  "update:modelValue": [value: boolean];
  retire: [id: string];
}>();

// ─── Display ──────────────────────────────────────────────────────────────────

const { mdAndUp } = useDisplay();

// ─── Actions ──────────────────────────────────────────────────────────────────

function confirmRetire(id: string): void {
  emit("retire", id);
  emit("update:modelValue", false);
}

function close(): void {
  emit("update:modelValue", false);
}
</script>

<template>
  <v-bottom-sheet
    :model-value="modelValue"
    :max-width="mdAndUp ? '50%' : undefined"
    @update:model-value="close"
  >
    <v-card
      v-if="habit"
      v-motion
      :initial="{ opacity: 0, y: 20 }"
      :enter="{ opacity: 1, y: 0, transition: { type: 'spring', stiffness: 300, damping: 22 } }"
      rounded="t-xl"
      :style="{ display: 'flex', flexDirection: 'column', minHeight: mdAndUp ? '230px' : '260px' }"
    >
      <v-card-title
        v-motion
        :initial="{ opacity: 0, y: 8 }"
        :enter="{
          opacity: 1,
          y: 0,
          transition: { type: 'spring', stiffness: 300, damping: 22, delay: 60 },
        }"
        class="pt-5 px-4"
      >
        <v-icon icon="mdi-star-shooting" color="success" class="mr-2" />
        Retire {{ habit.name }}?
      </v-card-title>

      <v-card-subtitle
        v-motion
        :initial="{ opacity: 0 }"
        :enter="{ opacity: 1, transition: { duration: 200, delay: 100 } }"
        class="px-4 pb-4 text-wrap"
      >
        {{ habit.streak }}-day streak. It won't be deleted.
      </v-card-subtitle>

      <v-divider />

      <v-card-actions
        v-motion
        :initial="{ opacity: 0, y: 12, scale: 0.95 }"
        :enter="{
          opacity: 1,
          y: 0,
          scale: 1,
          transition: { type: 'spring', stiffness: 300, damping: 22, delay: 140 },
        }"
        class="flex-column ga-3 pa-4 pt-3"
      >
        <v-btn
          block
          size="large"
          color="success"
          variant="tonal"
          rounded="lg"
          @click="confirmRetire(habit.id)"
        >
          Retire
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-bottom-sheet>
</template>
